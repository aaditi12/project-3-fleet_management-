from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'warehouse_fleet'

setup(
    name=package_name,
    version='1.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        # Required: register the package with the ament index
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        # Package manifest
        ('share/' + package_name, ['package.xml']),
        # Launch files
        (os.path.join('share', package_name, 'launch'),
            glob('launch/*.launch.py')),
        # Config files
        (os.path.join('share', package_name, 'config'),
            glob('config/*.yaml')),
        # Maps
        (os.path.join('share', package_name, 'maps'),
            glob('maps/*.md')),
        # RViz configs
        (os.path.join('share', package_name, 'rviz'),
            glob('rviz/*.rviz')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Your Name',
    maintainer_email='you@example.com',
    description='Warehouse Fleet Management System for ROS2 Humble',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            # ros2 run warehouse_fleet fleet_manager
            'fleet_manager     = warehouse_fleet.fleet_manager:main',
            # ros2 run warehouse_fleet robot_controller
            'robot_controller  = warehouse_fleet.robot_controller:main',
            # ros2 run warehouse_fleet task_dispatcher
            'task_dispatcher   = warehouse_fleet.task_dispatcher:main',
            # ros2 run warehouse_fleet warehouse_monitor
            'warehouse_monitor = warehouse_fleet.warehouse_monitor:main',
        ],
    },
)
