# 🏭 Warehouse Fleet Management System – ROS2 Humble

A beginner-friendly multi-robot fleet management project for ROS2 Humble.
No real hardware required – robots are fully simulated in software.

---

## 📋 Project Overview

This package demonstrates how to manage **multiple autonomous robots** in
a warehouse using ROS2's publisher/subscriber and parameter systems.

### What it does

| Feature | Description |
|---|---|
| **Fleet Manager** | Central "brain" – assigns tasks to idle robots |
| **Robot Controllers** | Each robot simulates movement, battery drain, charging |
| **Task Dispatcher** | Interactive CLI to inject pick/drop tasks at runtime |
| **Warehouse Monitor** | Live terminal dashboard showing all robot states |

### Warehouse layout

```
  X →  0   1   2   3   4   5   6   7  (metres)
Y ↓  ┌───────────────────────────────────┐
  0  │ 🔌  ·   ·   ·   ·   ·   ·   ·  │
  1  │  ·  [A] [B] [C]  ·   ·   ·   ·  │  ← Shelf Row 1
  2  │  ·   ·   ·   ·   ·   ·   ·   ·  │
  3  │  ·   ·   ·   ·   ·   ·   ·   ·  │
  4  │  ·  [D] [E] [F]  ·   ·   ·   ·  │  ← Shelf Row 2
  5  │  ·   ·   ·   ·   ·   ·   ·   ·  │
     └───────────────────────────────────┘
  🔌 = Charging station (0,0)   [X] = Pick shelf
```

---

## 🗂️ Package Structure

```
warehouse_fleet_ws/
└── src/
    └── warehouse_fleet/
        ├── package.xml
        ├── CMakeLists.txt
        ├── warehouse_fleet/           ← Python nodes
        │   ├── __init__.py
        │   ├── fleet_manager.py       ← Task assignment + robot tracking
        │   ├── robot_controller.py    ← Individual robot simulation
        │   ├── task_dispatcher.py     ← Interactive CLI task injector
        │   └── warehouse_monitor.py   ← Live terminal dashboard
        ├── launch/
        │   └── warehouse_fleet.launch.py
        ├── config/
        │   └── fleet_params.yaml
        ├── maps/
        │   └── README.md
        └── rviz/
            └── fleet_view.rviz
```

---

## 🔌 ROS2 Communication Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         ROS2 Topics                              │
│                                                                   │
│  /fleet_status ──────────────────────► warehouse_monitor        │
│       ▲                                                           │
│       │ (publish every 1s)                                        │
│  fleet_manager ◄──── /robot_1/status ── robot_controller_1      │
│       │         ◄──── /robot_2/status ── robot_controller_2      │
│       │         ◄──── /robot_3/status ── robot_controller_3      │
│       │                                                           │
│       └──────── /robot_1/goal ─────────► robot_controller_1     │
│       └──────── /robot_2/goal ─────────► robot_controller_2     │
│       └──────── /robot_3/goal ─────────► robot_controller_3     │
│                                                                   │
│  /add_task ─────────────────────────► fleet_manager             │
│       ▲                                                           │
│  task_dispatcher (CLI) ─────────────────────────────────────    │
└─────────────────────────────────────────────────────────────────┘
```

### Topic / Message Reference

| Topic | Type | Direction | Purpose |
|---|---|---|---|
| `/fleet_status` | `std_msgs/String` (JSON) | FleetManager → All | Full fleet snapshot |
| `/<robot>/status` | `std_msgs/String` (JSON) | Robot → FleetManager | Heartbeat + completion |
| `/<robot>/goal` | `std_msgs/String` (JSON) | FleetManager → Robot | New task assignment |
| `/<robot>/pose` | `geometry_msgs/Pose2D` | Robot → All | 2D position |
| `/add_task` | `std_msgs/String` (JSON) | CLI → FleetManager | Inject new task |

---

## 🚀 Prerequisites

```bash
# ROS2 Humble must be installed and sourced
source /opt/ros/humble/setup.bash

# Required packages (should already be present with Humble desktop)
sudo apt install ros-humble-rclpy ros-humble-geometry-msgs
```

---

## 🏗️ Build

```bash
cd ~/warehouse_fleet_ws
colcon build --packages-select warehouse_fleet
source install/setup.bash
```

---

## ▶️ Running

### Option A – Full launch (recommended)

```bash
# Terminal 1 – start everything
ros2 launch warehouse_fleet warehouse_fleet.launch.py

# With 5 robots instead of 3:
ros2 launch warehouse_fleet warehouse_fleet.launch.py num_robots:=5
```

### Option B – Nodes separately (good for learning)

```bash
# Terminal 1 – Fleet Manager
ros2 run warehouse_fleet fleet_manager.py

# Terminal 2 – Robot 1
ros2 run warehouse_fleet robot_controller.py \
  --ros-args -p robot_name:=robot_1 -p start_x:=0.0 -p start_y:=0.0

# Terminal 3 – Robot 2
ros2 run warehouse_fleet robot_controller.py \
  --ros-args -p robot_name:=robot_2 -p start_x:=1.0 -p start_y:=0.0

# Terminal 4 – Robot 3
ros2 run warehouse_fleet robot_controller.py \
  --ros-args -p robot_name:=robot_3 -p start_x:=2.0 -p start_y:=0.0

# Terminal 5 – Live dashboard
ros2 run warehouse_fleet warehouse_monitor.py

# Terminal 6 – Interactive task CLI (optional)
ros2 run warehouse_fleet task_dispatcher.py
```

---

## 🧑‍💻 Interacting at Runtime

### Inject a new task via CLI (task_dispatcher)

```
fleet> add 3.0 2.0 "Pick item from row 3"
fleet> list
fleet> status
fleet> help
```

### Inject a task directly with ros2 topic pub

```bash
ros2 topic pub --once /add_task std_msgs/String \
  "data: '{\"x\": 5.0, \"y\": 4.0, \"label\": \"Drop-off zone\"}'"
```

### Watch fleet status in raw JSON

```bash
ros2 topic echo /fleet_status
```

### Watch a single robot's pose

```bash
ros2 topic echo /robot_1/pose
```

### View the ROS2 node graph

```bash
rqt_graph
```

---

## 🧩 Key Concepts Demonstrated

| Concept | Where |
|---|---|
| **Publisher / Subscriber** | All nodes |
| **Parameters** | `fleet_manager.py`, `robot_controller.py` |
| **Multiple nodes** | Each robot is an independent node |
| **Namespacing** | `/robot_1/…`, `/robot_2/…` |
| **JSON over std_msgs** | Simple inter-node data exchange |
| **Timers** | Simulation ticks, status publishing |
| **Launch files** | `warehouse_fleet.launch.py` |
| **OpaqueFunction** | Dynamic robot node creation in launch |

---

## 🔋 Battery & Charging Simulation

- Robots drain **0.5% battery per second** while on a task.
- When battery drops below **15%**, the robot abandons its current task
  and autonomously drives to the charging station at **(0, 0)**.
- Robots recharge **1% per second** while IDLE.

---

## 📈 Next Steps (to extend this project)

1. **Real Nav2 integration** – Replace the simulated movement in
   `robot_controller.py` with actual Nav2 `NavigateToPose` action calls.
2. **Custom ROS2 messages** – Create `FleetStatus.msg`, `Task.msg`,
   `RobotState.msg` instead of JSON strings.
3. **RViz2 markers** – Publish `visualization_msgs/MarkerArray` to show
   robots and task positions on a 2D map.
4. **Priority queues** – Add task priority levels in `fleet_manager.py`.
5. **Collision zones** – Implement grid-based reservation so two robots
   never enter the same cell.
6. **Web dashboard** – Add `rosbridge_suite` + a React/HTML frontend.

---

## 🐛 Troubleshooting

| Problem | Fix |
|---|---|
| `ModuleNotFoundError: warehouse_fleet` | Re-run `colcon build` and `source install/setup.bash` |
| Robot shows ERROR status | Robot controller probably not running – check terminals |
| Tasks stuck in PENDING | No IDLE robots (all BUSY or CHARGING) – wait or add more robots |
| Monitor shows blank | Start `fleet_manager` first, then monitor |

---

## 📄 License

Apache 2.0 – free to use, modify, and distribute.
