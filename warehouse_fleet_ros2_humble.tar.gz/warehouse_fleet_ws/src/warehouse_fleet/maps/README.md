# Maps Directory

Place your warehouse occupancy-grid maps here.

## File format
ROS2 map files consist of two files:
  - `warehouse.pgm`  – greyscale image (255=free, 0=obstacle)
  - `warehouse.yaml` – metadata (resolution, origin, thresholds)

## Example warehouse.yaml
```yaml
image: warehouse.pgm
resolution: 0.05          # metres per pixel
origin: [0.0, 0.0, 0.0]   # [x, y, yaw] of bottom-left pixel
negate: 0
occupied_thresh: 0.65
free_thresh: 0.196
```

## Generating a simple map
Use the ROS2 map server to save a map after driving a robot around:
  ros2 run nav2_map_server map_saver_cli -f warehouse

Or use a static map image for simulation.

## Warehouse Layout (text art)
```
  0   1   2   3   4   5   6   7  (metres X)
  ┌───────────────────────────────────┐
0 │ 🔌C  .   .   .   .   .   .   .  │
1 │  .  [A] [B] [C]  .   .   .   .  │  ← Shelf Row 1
2 │  .   .   .   .   .   .   .   .  │  ← Aisle
3 │  .   .   .   .   .   .   .   .  │  ← Aisle
4 │  .  [D] [E] [F]  .   .   .   .  │  ← Shelf Row 2
5 │  .   .   .   .   .   .   .   .  │
  └───────────────────────────────────┘

Key:
  🔌C  = Charging station (0,0)
  [X]  = Shelf / pick location
  .    = Free space / aisle
```
