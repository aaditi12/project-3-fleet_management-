#!/bin/bash
# ============================================================
#  quick_start.sh – Build & run the warehouse fleet
#  Usage:  bash quick_start.sh [num_robots]
#  Requires: ROS2 Humble sourced, optionally tmux
# ============================================================
set -e

NUM_ROBOTS=${1:-3}
WS_DIR="$(cd "$(dirname "$0")/../../.." && pwd)"

echo "=================================================="
echo " Warehouse Fleet Management – Quick Start"
echo " Workspace : $WS_DIR"
echo " Robots    : $NUM_ROBOTS"
echo "=================================================="

source /opt/ros/humble/setup.bash

echo "[1/3] Building workspace …"
cd "$WS_DIR"
colcon build --packages-select warehouse_fleet --symlink-install
source install/setup.bash
echo "[2/3] Build complete."

if command -v tmux &>/dev/null; then
    echo "[3/3] Launching in tmux session 'fleet' …"
    tmux kill-session -t fleet 2>/dev/null || true
    tmux new-session -d -s fleet -x 220 -y 50

    # Pane 0 – Fleet Manager
    tmux send-keys -t fleet \
      "source /opt/ros/humble/setup.bash && source $WS_DIR/install/setup.bash && ros2 run warehouse_fleet fleet_manager --ros-args -p num_robots:=$NUM_ROBOTS" Enter
    sleep 1

    # One pane per robot
    for i in $(seq 1 $NUM_ROBOTS); do
        tmux split-window -t fleet -v
        tmux send-keys -t fleet \
          "source /opt/ros/humble/setup.bash && source $WS_DIR/install/setup.bash && ros2 run warehouse_fleet robot_controller --ros-args -p robot_name:=robot_$i -p start_x:=$((i-1)).0 -p start_y:=0.0" Enter
        sleep 0.3
    done

    # Monitor pane
    tmux split-window -t fleet -v
    tmux send-keys -t fleet \
      "source /opt/ros/humble/setup.bash && source $WS_DIR/install/setup.bash && ros2 run warehouse_fleet warehouse_monitor" Enter

    # Task dispatcher pane
    tmux split-window -t fleet -h
    tmux send-keys -t fleet \
      "source /opt/ros/humble/setup.bash && source $WS_DIR/install/setup.bash && sleep 2 && ros2 run warehouse_fleet task_dispatcher" Enter

    tmux select-layout -t fleet tiled
    tmux attach -t fleet
else
    echo "[3/3] tmux not found – using launch file …"
    ros2 launch warehouse_fleet warehouse_fleet.launch.py num_robots:=$NUM_ROBOTS
fi
