"""
warehouse_fleet.launch.py
=========================
Launches:
  1. fleet_manager        – central task coordinator
  2. robot_1 … robot_N    – individual robot controllers
  3. warehouse_monitor    – live terminal dashboard

Usage:
  ros2 launch warehouse_fleet warehouse_fleet.launch.py
  ros2 launch warehouse_fleet warehouse_fleet.launch.py num_robots:=5
"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction, LogInfo
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


# Predefined start positions (x, y) for up to 8 robots
ROBOT_STARTS = [
    (0.0, 0.0),
    (1.0, 0.0),
    (2.0, 0.0),
    (3.0, 0.0),
    (4.0, 0.0),
    (0.0, 1.0),
    (1.0, 1.0),
    (2.0, 1.0),
]


def generate_launch_description():

    num_robots_arg = DeclareLaunchArgument(
        'num_robots',
        default_value='3',
        description='Number of warehouse robots to spawn (max 8)',
    )

    fleet_manager_node = Node(
        package='warehouse_fleet',
        executable='fleet_manager',          # ← no .py
        name='fleet_manager',
        output='screen',
        parameters=[{
            'num_robots':      LaunchConfiguration('num_robots'),
            'status_rate_hz':  1.0,
            'robot_timeout_s': 5.0,
        }],
        emulate_tty=True,
    )

    monitor_node = Node(
        package='warehouse_fleet',
        executable='warehouse_monitor',      # ← no .py
        name='warehouse_monitor',
        output='screen',
        emulate_tty=True,
    )

    def spawn_robots(context, *args, **kwargs):
        n = int(LaunchConfiguration('num_robots').perform(context))
        n = max(1, min(n, len(ROBOT_STARTS)))
        nodes = []
        for i in range(1, n + 1):
            name = f'robot_{i}'
            sx, sy = ROBOT_STARTS[i - 1]
            nodes.append(
                Node(
                    package='warehouse_fleet',
                    executable='robot_controller',   # ← no .py
                    name=name,
                    output='screen',
                    parameters=[{
                        'robot_name': name,
                        'start_x':    sx,
                        'start_y':    sy,
                    }],
                    emulate_tty=True,
                )
            )
        return nodes

    return LaunchDescription([
        num_robots_arg,
        LogInfo(msg='=== Starting Warehouse Fleet Management System ==='),
        fleet_manager_node,
        OpaqueFunction(function=spawn_robots),
        monitor_node,
    ])
