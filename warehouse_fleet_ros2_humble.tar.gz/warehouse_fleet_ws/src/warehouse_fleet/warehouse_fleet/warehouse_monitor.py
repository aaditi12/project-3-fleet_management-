#!/usr/bin/env python3
"""
Warehouse Monitor Node
======================
Prints a live terminal dashboard that refreshes every second.

Shows:
  - Robot table  (name, status, battery, position, current task)
  - Task summary (pending / assigned / done / failed counts)
  - Recent task list with assignment info

Run:
  ros2 run warehouse_fleet warehouse_monitor.py
"""

import json
import os
import time

import rclpy
from rclpy.node import Node
from std_msgs.msg import String


# ANSI colours (work on Linux/macOS terminal)
RED    = "\033[91m"
GREEN  = "\033[92m"
YELLOW = "\033[93m"
BLUE   = "\033[94m"
CYAN   = "\033[96m"
BOLD   = "\033[1m"
RESET  = "\033[0m"

STATUS_COLOUR = {
    "IDLE":     GREEN,
    "BUSY":     YELLOW,
    "CHARGING": CYAN,
    "ERROR":    RED,
}


def colour_status(s: str) -> str:
    c = STATUS_COLOUR.get(s, "")
    return f"{c}{s:<10}{RESET}"


def battery_bar(pct: float, width: int = 10) -> str:
    filled = int(pct / 100 * width)
    bar    = "█" * filled + "░" * (width - filled)
    colour = GREEN if pct > 50 else (YELLOW if pct > 20 else RED)
    return f"{colour}[{bar}]{RESET} {pct:5.1f}%"


class WarehouseMonitor(Node):

    def __init__(self):
        super().__init__("warehouse_monitor")
        self.latest: dict = {}
        self.create_subscription(
            String, "/fleet_status", self._cb, 10
        )
        self.create_timer(1.0, self._render)
        self.get_logger().info("Warehouse Monitor started.")

    def _cb(self, msg: String):
        try:
            self.latest = json.loads(msg.data)
        except json.JSONDecodeError:
            pass

    def _render(self):
        # Clear terminal
        os.system("clear" if os.name == "posix" else "cls")

        now_str = time.strftime("%H:%M:%S")
        print(f"{BOLD}{BLUE}╔══════════════════════════════════════════════════════════╗{RESET}")
        print(f"{BOLD}{BLUE}║      🏭  Warehouse Fleet Monitor  –  {now_str}         ║{RESET}")
        print(f"{BOLD}{BLUE}╚══════════════════════════════════════════════════════════╝{RESET}")

        if not self.latest:
            print(f"\n  {YELLOW}Waiting for fleet_status …{RESET}")
            print("  Is fleet_manager running?")
            return

        # ── Robots ──────────────────────────────────────────────────────
        print(f"\n{BOLD}  ROBOTS{RESET}")
        print(f"  {'Name':<12} {'Status':<18} {'Battery':<22} {'Position':<18} {'Task'}")
        print(f"  {'─'*12} {'─'*16} {'─'*20} {'─'*16} {'─'*6}")

        for r in self.latest.get("robots", []):
            name    = r["name"]
            status  = colour_status(r["status"])
            batt    = battery_bar(r["battery"])
            pos     = f"({r['position']['x']:.1f},{r['position']['y']:.1f})"
            task_id = r["current_task"] if r["current_task"] >= 0 else "–"
            print(f"  {name:<12} {status:<28} {batt}  {pos:<18} {task_id}")

        # ── Task Summary ────────────────────────────────────────────────
        tasks = self.latest.get("tasks", {})
        print(f"\n{BOLD}  TASK SUMMARY{RESET}")
        pending  = tasks.get("pending",  0)
        assigned = tasks.get("assigned", 0)
        done     = tasks.get("done",     0)
        failed   = tasks.get("failed",   0)
        total    = pending + assigned + done + failed
        print(
            f"  Total={total}  "
            f"{YELLOW}Pending={pending}{RESET}  "
            f"{CYAN}Assigned={assigned}{RESET}  "
            f"{GREEN}Done={done}{RESET}  "
            f"{RED}Failed={failed}{RESET}"
        )

        # ── Task Details ────────────────────────────────────────────────
        details = tasks.get("details", [])
        if details:
            print(f"\n{BOLD}  TASK LIST{RESET}")
            print(f"  {'ID':>4} {'Status':<12} {'Label':<28} {'Assigned To'}")
            print(f"  {'─'*4} {'─'*10} {'─'*26} {'─'*12}")
            for t in details[-15:]:   # show most recent 15
                s     = t["status"]
                sc    = (GREEN  if s == "DONE"
                         else RED     if s == "FAILED"
                         else YELLOW  if s == "ASSIGNED"
                         else RESET)
                robot = t["assigned_to"] or "–"
                print(
                    f"  {t['task_id']:>4} {sc}{s:<12}{RESET}"
                    f" {t['label']:<28} {robot}"
                )

        print(f"\n  {BLUE}Press Ctrl+C to exit.{RESET}\n")


def main(args=None):
    rclpy.init(args=args)
    node = WarehouseMonitor()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
