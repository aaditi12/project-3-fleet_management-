#!/usr/bin/env python3
"""
Robot Controller Node
=====================
Simulates one warehouse robot.

Each robot:
  - Has a name (robot_1, robot_2, …) passed as a ROS parameter
  - Starts at a configurable home position
  - Listens on /<name>/goal for task assignments from the FleetManager
  - Moves toward the goal in small simulation steps (no real hardware needed)
  - Publishes its status JSON on /<name>/status every second
  - Reports task completion back to the FleetManager via the same status topic
  - Drains battery while BUSY, charges while IDLE near the charging station

Topics subscribed:
  /<robot_name>/goal    (std_msgs/String) – JSON goal from FleetManager

Topics published:
  /<robot_name>/status  (std_msgs/String) – JSON heartbeat
  /<robot_name>/pose    (geometry_msgs/Pose2D) – current 2-D pose

Run one robot (example):
  ros2 run warehouse_fleet robot_controller.py \
    --ros-args -p robot_name:=robot_1 -p start_x:=0.0 -p start_y:=0.0
"""

import math
import json
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from geometry_msgs.msg import Pose2D


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

MOVE_SPEED      = 0.5   # metres per simulation tick (1 Hz → 0.5 m/s sim speed)
ARRIVAL_THRESH  = 0.2   # metres – how close = "arrived"
BATTERY_DRAIN   = 0.5   # % per tick while BUSY
BATTERY_CHARGE  = 1.0   # % per tick while IDLE (simulated charging)
LOW_BATTERY     = 15.0  # % threshold → go to charging station
CHARGE_STATION  = (0.0, 0.0)


class RobotController(Node):

    def __init__(self):
        super().__init__("robot_controller")

        # ---- Parameters -------------------------------------------------------
        self.declare_parameter("robot_name", "robot_1")
        self.declare_parameter("start_x",    0.0)
        self.declare_parameter("start_y",    0.0)

        self.robot_name = self.get_parameter("robot_name").value
        x0 = self.get_parameter("start_x").value
        y0 = self.get_parameter("start_y").value

        # ---- State ------------------------------------------------------------
        self.x:       float = float(x0)
        self.y:       float = float(y0)
        self.status:  str   = "IDLE"
        self.battery: float = 100.0

        self.current_task_id:   int   = -1
        self.goal_x:            float = x0
        self.goal_y:            float = y0
        self.goal_label:        str   = ""
        self.finished_task_id:  int   = -1   # reported once on completion

        # ---- Publishers -------------------------------------------------------
        self.status_pub = self.create_publisher(
            String, f"/{self.robot_name}/status", 10
        )
        self.pose_pub = self.create_publisher(
            Pose2D, f"/{self.robot_name}/pose", 10
        )

        # ---- Subscriber -------------------------------------------------------
        self.create_subscription(
            String,
            f"/{self.robot_name}/goal",
            self._goal_cb,
            10,
        )

        # ---- Timer (simulation tick = 1 Hz) -----------------------------------
        self.create_timer(1.0, self._tick)

        self.get_logger().info(
            f"{self.robot_name} online at ({self.x:.1f}, {self.y:.1f})"
        )

    # ------------------------------------------------------------------
    # Goal callback
    # ------------------------------------------------------------------

    def _goal_cb(self, msg: String):
        try:
            data = json.loads(msg.data)
        except json.JSONDecodeError:
            self.get_logger().warning("Bad JSON goal received.")
            return

        self.current_task_id = int(data.get("task_id", -1))
        goal = data.get("goal", {})
        self.goal_x          = float(goal.get("x", self.x))
        self.goal_y          = float(goal.get("y", self.y))
        self.goal_label      = data.get("label", "")
        self.status          = "BUSY"
        self.finished_task_id = -1

        self.get_logger().info(
            f"{self.robot_name} received goal: {self.goal_label} "
            f"→ ({self.goal_x:.1f}, {self.goal_y:.1f})"
        )

    # ------------------------------------------------------------------
    # Simulation tick
    # ------------------------------------------------------------------

    def _tick(self):
        # ---- Battery management -------------------------------------------
        if self.status == "BUSY":
            self.battery = max(0.0, self.battery - BATTERY_DRAIN)
        elif self.status in ("IDLE", "CHARGING"):
            self.battery = min(100.0, self.battery + BATTERY_CHARGE)

        # ---- Low-battery emergency ----------------------------------------
        if self.battery <= LOW_BATTERY and self.status == "BUSY":
            self.get_logger().warning(
                f"{self.robot_name} battery low ({self.battery:.1f}%) – "
                f"returning to charge station."
            )
            self.goal_x   = CHARGE_STATION[0]
            self.goal_y   = CHARGE_STATION[1]
            self.status   = "CHARGING"
            self.goal_label = "Charging Station"
            # Do NOT clear current_task_id – FleetManager will re-queue it

        # ---- Move toward goal ---------------------------------------------
        if self.status in ("BUSY", "CHARGING"):
            dx = self.goal_x - self.x
            dy = self.goal_y - self.y
            dist = math.hypot(dx, dy)

            if dist <= ARRIVAL_THRESH:
                # Arrived!
                self.x = self.goal_x
                self.y = self.goal_y
                self._on_arrival()
            else:
                step = min(MOVE_SPEED, dist)
                self.x += (dx / dist) * step
                self.y += (dy / dist) * step

        # ---- Publish heartbeat --------------------------------------------
        self._publish_status()
        self._publish_pose()

    def _on_arrival(self):
        if self.status == "CHARGING":
            self.status = "IDLE"
            self.get_logger().info(
                f"{self.robot_name} reached charging station – charging."
            )
            return

        if self.current_task_id >= 0:
            self.finished_task_id = self.current_task_id
            self.get_logger().info(
                f"{self.robot_name} completed task {self.finished_task_id} "
                f"({self.goal_label})"
            )
            self.current_task_id = -1
            self.status = "IDLE"

    # ------------------------------------------------------------------
    # Publishers
    # ------------------------------------------------------------------

    def _publish_status(self):
        payload = {
            "status":   self.status,
            "battery":  round(self.battery, 1),
            "position": {"x": round(self.x, 3), "y": round(self.y, 3)},
        }
        # Report task completion once per tick after arrival
        if self.finished_task_id > 0:
            payload["finished_task_id"] = self.finished_task_id
            payload["task_result"]      = "DONE"
            self.finished_task_id       = -1   # clear after reporting

        self.status_pub.publish(String(data=json.dumps(payload)))

    def _publish_pose(self):
        pose      = Pose2D()
        pose.x    = self.x
        pose.y    = self.y
        pose.theta = 0.0   # heading not simulated
        self.pose_pub.publish(pose)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main(args=None):
    rclpy.init(args=args)
    node = RobotController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
