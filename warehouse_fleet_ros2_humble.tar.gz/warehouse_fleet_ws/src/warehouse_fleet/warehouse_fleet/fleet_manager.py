#!/usr/bin/env python3
"""
Fleet Manager Node
==================
The brain of the warehouse fleet system.

Responsibilities:
  - Tracks the state of every robot (position, status, battery)
  - Maintains a queue of pending tasks (go-to-location orders)
  - Assigns tasks to the most suitable idle robot
  - Publishes a fleet-wide status topic for the monitor dashboard
  - Provides a /assign_task service so external callers can add tasks

Topics published:
  /fleet_status          (std_msgs/String)  – JSON snapshot of all robots

Topics subscribed:
  /robot_<N>/status      (std_msgs/String)  – heartbeat from each robot controller

Services provided:
  /assign_task           (std_srvs/Trigger-like via std_msgs) – add a task via CLI

Usage (after building & sourcing):
  ros2 run warehouse_fleet fleet_manager.py
"""

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import json
import time


# ---------------------------------------------------------------------------
# Simple data classes
# ---------------------------------------------------------------------------

class Task:
    _counter = 0

    def __init__(self, goal_x: float, goal_y: float, label: str = ""):
        Task._counter += 1
        self.task_id   = Task._counter
        self.goal_x    = goal_x
        self.goal_y    = goal_y
        self.label     = label or f"Task-{self.task_id}"
        self.assigned_to: str = ""        # robot name
        self.status    = "PENDING"        # PENDING | ASSIGNED | DONE | FAILED
        self.created_at = time.time()

    def to_dict(self) -> dict:
        return {
            "task_id":     self.task_id,
            "label":       self.label,
            "goal":        {"x": self.goal_x, "y": self.goal_y},
            "assigned_to": self.assigned_to,
            "status":      self.status,
        }


class RobotInfo:
    def __init__(self, name: str):
        self.name        = name
        self.status      = "IDLE"   # IDLE | BUSY | CHARGING | ERROR
        self.position    = {"x": 0.0, "y": 0.0}
        self.battery     = 100.0    # percent
        self.current_task: int = -1
        self.last_seen   = time.time()

    def to_dict(self) -> dict:
        return {
            "name":         self.name,
            "status":       self.status,
            "position":     self.position,
            "battery":      round(self.battery, 1),
            "current_task": self.current_task,
        }


# ---------------------------------------------------------------------------
# Fleet Manager Node
# ---------------------------------------------------------------------------

class FleetManager(Node):

    def __init__(self):
        super().__init__("fleet_manager")

        # ---- Parameters -------------------------------------------------------
        self.declare_parameter("num_robots",       3)
        self.declare_parameter("status_rate_hz",   1.0)   # how often to publish
        self.declare_parameter("robot_timeout_s",  5.0)   # seconds before warn

        num_robots     = self.get_parameter("num_robots").value
        status_rate_hz = self.get_parameter("status_rate_hz").value

        # ---- Internal state ---------------------------------------------------
        # robot name → RobotInfo
        self.robots: dict[str, RobotInfo] = {}
        for i in range(1, num_robots + 1):
            name = f"robot_{i}"
            self.robots[name] = RobotInfo(name)

        # task list (all tasks ever created)
        self.tasks: list[Task] = []

        # Pre-load some demo tasks for the warehouse
        self._load_demo_tasks()

        # ---- Publishers -------------------------------------------------------
        self.fleet_status_pub = self.create_publisher(
            String, "/fleet_status", 10
        )

        # ---- Subscribers – one per robot -------------------------------------
        for name in self.robots:
            self.create_subscription(
                String,
                f"/{name}/status",
                lambda msg, n=name: self._robot_status_cb(msg, n),
                10,
            )

        # ---- Subscriber – task injection from CLI ----------------------------
        # Publish a JSON string to /add_task to inject a new task at runtime:
        #   ros2 topic pub --once /add_task std_msgs/String \
        #     "data: '{\"x\": 2.0, \"y\": 3.0, \"label\": \"Pick shelf-A\"}'"
        self.create_subscription(String, "/add_task", self._add_task_cb, 10)

        # ---- Timers -----------------------------------------------------------
        period = 1.0 / max(status_rate_hz, 0.1)
        self.create_timer(period,        self._publish_fleet_status)
        self.create_timer(1.0,           self._dispatch_tasks)        # every 1 s
        self.create_timer(2.0,           self._check_robot_timeouts)  # every 2 s

        self.get_logger().info(
            f"FleetManager started – managing {num_robots} robots."
        )

    # ------------------------------------------------------------------
    # Demo task setup
    # ------------------------------------------------------------------

    def _load_demo_tasks(self):
        """Pre-populate with typical warehouse waypoints."""
        waypoints = [
            ( 2.0,  1.0, "Pick – Shelf A"),
            ( 4.0,  1.0, "Pick – Shelf B"),
            ( 6.0,  1.0, "Pick – Shelf C"),
            ( 2.0,  4.0, "Pick – Shelf D"),
            ( 4.0,  4.0, "Pick – Shelf E"),
            ( 6.0,  4.0, "Pick – Shelf F"),
            ( 0.0,  0.0, "Return – Charging Station"),
        ]
        for x, y, label in waypoints:
            self.tasks.append(Task(x, y, label))

        self.get_logger().info(
            f"Loaded {len(self.tasks)} demo tasks into the queue."
        )

    # ------------------------------------------------------------------
    # Callbacks
    # ------------------------------------------------------------------

    def _robot_status_cb(self, msg: String, robot_name: str):
        """Receive heartbeat / status update from a robot controller."""
        try:
            data = json.loads(msg.data)
        except json.JSONDecodeError:
            self.get_logger().warning(
                f"Bad JSON from {robot_name}: {msg.data!r}"
            )
            return

        robot = self.robots.get(robot_name)
        if robot is None:
            return

        robot.last_seen = time.time()
        robot.status    = data.get("status",   robot.status)
        robot.battery   = float(data.get("battery", robot.battery))

        pos = data.get("position", {})
        if pos:
            robot.position["x"] = float(pos.get("x", robot.position["x"]))
            robot.position["y"] = float(pos.get("y", robot.position["y"]))

        # If robot reports task completed / failed – update task record
        finished_task_id = data.get("finished_task_id", -1)
        if finished_task_id > 0:
            self._handle_task_completion(robot_name, finished_task_id, data.get("task_result", "DONE"))

    def _add_task_cb(self, msg: String):
        """Dynamically add a task via /add_task topic."""
        try:
            data  = json.loads(msg.data)
            task  = Task(
                goal_x=float(data["x"]),
                goal_y=float(data["y"]),
                label=data.get("label", ""),
            )
            self.tasks.append(task)
            self.get_logger().info(
                f"New task added: {task.label} → ({task.goal_x}, {task.goal_y})"
            )
        except (KeyError, ValueError) as e:
            self.get_logger().error(f"/add_task bad payload: {e}")

    # ------------------------------------------------------------------
    # Task dispatch logic
    # ------------------------------------------------------------------

    def _dispatch_tasks(self):
        """Assign PENDING tasks to IDLE robots (simple FIFO + nearest idle)."""
        pending = [t for t in self.tasks if t.status == "PENDING"]
        if not pending:
            return

        idle_robots = [r for r in self.robots.values() if r.status == "IDLE"]
        if not idle_robots:
            return

        for task in pending:
            if not idle_robots:
                break

            # Pick the idle robot closest to the task goal (simple Euclidean)
            best = min(
                idle_robots,
                key=lambda r: self._dist(r.position, task.goal_x, task.goal_y),
            )

            # Assign
            task.assigned_to = best.name
            task.status      = "ASSIGNED"
            best.status      = "BUSY"
            best.current_task = task.task_id
            idle_robots.remove(best)

            # Tell the robot what to do
            self._send_goal_to_robot(best.name, task)

            self.get_logger().info(
                f"Assigned {task.label} (id={task.task_id}) "
                f"→ {best.name}  goal=({task.goal_x:.1f},{task.goal_y:.1f})"
            )

    def _send_goal_to_robot(self, robot_name: str, task: Task):
        """Publish goal to the robot's command topic."""
        # We use a simple JSON command topic.
        # In a real system you'd use the nav2 action client here.
        topic = f"/{robot_name}/goal"

        # Lazy-create publisher (cache it)
        if not hasattr(self, "_goal_pubs"):
            self._goal_pubs: dict = {}
        if robot_name not in self._goal_pubs:
            self._goal_pubs[robot_name] = self.create_publisher(
                String, topic, 10
            )

        payload = json.dumps({
            "task_id": task.task_id,
            "goal":    {"x": task.goal_x, "y": task.goal_y},
            "label":   task.label,
        })
        self._goal_pubs[robot_name].publish(String(data=payload))

    def _handle_task_completion(self, robot_name: str, task_id: int, result: str):
        for task in self.tasks:
            if task.task_id == task_id and task.assigned_to == robot_name:
                task.status = result  # "DONE" or "FAILED"
                self.get_logger().info(
                    f"Task {task_id} ({task.label}) → {result} by {robot_name}"
                )
                break

        robot = self.robots.get(robot_name)
        if robot:
            robot.status       = "IDLE"
            robot.current_task = -1

    # ------------------------------------------------------------------
    # Status publisher
    # ------------------------------------------------------------------

    def _publish_fleet_status(self):
        snapshot = {
            "timestamp": time.time(),
            "robots":    [r.to_dict() for r in self.robots.values()],
            "tasks": {
                "pending":  sum(1 for t in self.tasks if t.status == "PENDING"),
                "assigned": sum(1 for t in self.tasks if t.status == "ASSIGNED"),
                "done":     sum(1 for t in self.tasks if t.status == "DONE"),
                "failed":   sum(1 for t in self.tasks if t.status == "FAILED"),
                "details":  [t.to_dict() for t in self.tasks],
            },
        }
        self.fleet_status_pub.publish(String(data=json.dumps(snapshot)))

    # ------------------------------------------------------------------
    # Watchdog
    # ------------------------------------------------------------------

    def _check_robot_timeouts(self):
        timeout = self.get_parameter("robot_timeout_s").value
        now     = time.time()
        for robot in self.robots.values():
            if now - robot.last_seen > timeout:
                if robot.status != "ERROR":
                    self.get_logger().warning(
                        f"{robot.name} has not reported in >{timeout}s – "
                        f"marking ERROR"
                    )
                    robot.status = "ERROR"

    # ------------------------------------------------------------------
    # Helper
    # ------------------------------------------------------------------

    @staticmethod
    def _dist(pos: dict, gx: float, gy: float) -> float:
        return ((pos["x"] - gx) ** 2 + (pos["y"] - gy) ** 2) ** 0.5


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main(args=None):
    rclpy.init(args=args)
    node = FleetManager()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
