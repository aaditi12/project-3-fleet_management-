#!/usr/bin/env python3
"""
Task Dispatcher Node
====================
Interactive command-line node that lets you type task commands and sends
them to the FleetManager via the /add_task topic.

Run it alongside the fleet:
  ros2 run warehouse_fleet task_dispatcher.py

Then type commands like:
  add 3.0 2.5 "Fetch item from row 3"
  list
  help
  quit
"""

import json
import threading
import rclpy
from rclpy.node import Node
from std_msgs.msg import String


HELP_TEXT = """
Task Dispatcher Commands
------------------------
  add <x> <y> [label]   – Send a new task to the FleetManager
                          Example: add 4.0 2.0 "Pick shelf-C"

  list                  – Print all tasks currently tracked (via /fleet_status)

  status                – Show latest fleet snapshot

  help                  – Show this help message

  quit / exit           – Shutdown the dispatcher
"""


class TaskDispatcher(Node):

    def __init__(self):
        super().__init__("task_dispatcher")

        self.task_pub = self.create_publisher(String, "/add_task", 10)

        self.latest_fleet_status: dict = {}
        self.create_subscription(
            String, "/fleet_status", self._fleet_status_cb, 10
        )

        self.get_logger().info("Task Dispatcher ready. Type 'help' for commands.")

    def _fleet_status_cb(self, msg: String):
        try:
            self.latest_fleet_status = json.loads(msg.data)
        except json.JSONDecodeError:
            pass

    def send_task(self, x: float, y: float, label: str = ""):
        payload = json.dumps({"x": x, "y": y, "label": label})
        self.task_pub.publish(String(data=payload))
        print(f"  → Dispatched task: {label or 'unlabelled'} @ ({x}, {y})")

    def print_fleet_status(self):
        fs = self.latest_fleet_status
        if not fs:
            print("  (No fleet status received yet – is fleet_manager running?)")
            return

        robots = fs.get("robots", [])
        print("\n── Robots ────────────────────────────────────")
        for r in robots:
            print(
                f"  {r['name']:<12} status={r['status']:<10} "
                f"battery={r['battery']:5.1f}%  "
                f"pos=({r['position']['x']:.1f},{r['position']['y']:.1f})  "
                f"task={r['current_task']}"
            )

        tasks = fs.get("tasks", {})
        print(f"\n── Tasks  ────────────────────────────────────")
        print(
            f"  Pending={tasks.get('pending',0)}  "
            f"Assigned={tasks.get('assigned',0)}  "
            f"Done={tasks.get('done',0)}  "
            f"Failed={tasks.get('failed',0)}"
        )
        details = tasks.get("details", [])
        for t in details:
            print(
                f"  [{t['task_id']:>3}] {t['status']:<10} "
                f"{t['label']:<25}  "
                f"robot={t['assigned_to'] or '-'}"
            )
        print()

    def run_interactive(self):
        """Blocking CLI loop – must be called from a separate thread."""
        print(HELP_TEXT)
        while rclpy.ok():
            try:
                line = input("fleet> ").strip()
            except EOFError:
                break

            if not line:
                continue

            parts = line.split(None, 3)
            cmd   = parts[0].lower()

            if cmd in ("quit", "exit", "q"):
                print("Shutting down task dispatcher …")
                rclpy.shutdown()
                break

            elif cmd == "help":
                print(HELP_TEXT)

            elif cmd in ("status", "list"):
                self.print_fleet_status()

            elif cmd == "add":
                if len(parts) < 3:
                    print("  Usage: add <x> <y> [label]")
                    continue
                try:
                    x = float(parts[1])
                    y = float(parts[2])
                    label = parts[3].strip('"') if len(parts) > 3 else ""
                    self.send_task(x, y, label)
                except ValueError:
                    print("  x and y must be numbers.")

            else:
                print(f"  Unknown command: {cmd!r}  (type 'help')")


def main(args=None):
    rclpy.init(args=args)
    node = TaskDispatcher()

    # Spin ROS in a background thread so the CLI is non-blocking
    spin_thread = threading.Thread(target=rclpy.spin, args=(node,), daemon=True)
    spin_thread.start()

    node.run_interactive()

    node.destroy_node()


if __name__ == "__main__":
    main()
